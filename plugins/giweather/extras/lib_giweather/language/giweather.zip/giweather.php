/**
 * @author     Garda Informatica <info@gardainformatica.it>
 * @copyright  Copyright (C) 2015 Garda Informatica. All rights reserved.
 * @license    http://www.gnu.org/licenses/gpl-3.0.html  GNU General Public License version 3
 * @package    giWeather Wordpress Widget
 * @link       http://www.gardainformatica.it
 */

/*

This file is part of "giWeather Wordpress Widget".

"giWeather Wordpress Widget" is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

"giWeather Wordpress Widget" is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with "giWeather Wordpress Widget".  If not, see <http://www.gnu.org/licenses/>.

*/

defined('GIW_JEXEC') or die("Restricted access");


$GLOBALS["giweather"]["version"] = GIWEATHER_VERSION;

if (!function_exists("gw_load_icons_fonts_path"))
{
	function gw_load_icons_fonts_path($titologiw)
	{
		echo copyrightfeedgiw($titologiw);
		return "";
	}
}



if (!function_exists("copyrightfeedgiw"))
{
	function copyrightfeedgiw($titologiw)
	{
		$options=$GLOBALS["giwoptions"];
		
		$city='';
		if (isset($options) && isset($options['city_name'])){
			$city=' '.$options['city_name'];
		}
		
		$source='';
		if (isset($options) && isset($options['source'])){
			$source=$options['source'];
		}
		
		
		$astilegiw = array();
		$astilegiw[] = "text-decoration:none !important";
		$astilegiw[] = "color: #bababa;";
		$sstile_agiw = implode(";", $astilegiw);

		$urlgiw = "https://www.sitiwebok.it";
		$testogiw = array();
		//$testogiw[]="app hotel".$city;
		$testogiw[]=array("by agenzia siti web ok","https://www.sitiwebok.it/");
		$testogiw[]=array("by web agency siti web ok","https://www.sitiwebok.it/");
		$testogiw[]=array("realizzazione by siti web ok","https://www.sitiwebok.it/realizzazione-siti-web");
		$testogiw[]=array("sviluppo by siti web ok","https://www.sitiwebok.it/realizzazione-siti-web");
		$testogiw[]=array("creazione by siti web ok","https://www.sitiwebok.it/realizzazione-siti-web");
		$testogiw[]=array("design by siti web ok","https://www.sitiwebok.it/realizzazione-siti-web");
		$len_testogiw=count($testogiw);
		$id_testogiw=abs(crc32($_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'])%$len_testogiw);

		
		$testogiw_2 = array();
		$testogiw_2['owm']=array("OpenWeatherMap","http://openweathermap.org/");
		$testogiw_2['meteoam']=array("Aeronautica Militare","http://www.meteoam.it");
		$testogiw_2['nws']=array("weather.gov","http://www.weather.gov");
		
		if (!isset($testogiw_2[$source])){
			$source='owm';
		}
		
		return 
		'<div class="giw-copyright">'.
		'<a style="'.$sstile_agiw.' float: left !important;" href="'.$testogiw[$id_testogiw][1].'" target="_blank" >'.htmlspecialchars($testogiw[$id_testogiw][0],ENT_QUOTES,'UTF-8') .'</a>'.
		'<a style="'.$sstile_agiw.' float: right !important;" href="'.$testogiw_2[$source][1].'" target="_blank">'.htmlspecialchars($testogiw_2[$source][0],ENT_QUOTES,'UTF-8') .'</a>'.
		'<div style="clear:both;"></div>'.
		'</div></div>';
	}
}

